<?php include('partials/menu.php'); ?>


    <!-- Menu Content Section Starts -->
    <div class ="main-content">

        <div class = "wrapper">
            <h1>Manage Admin</h1>

             
         </div>

    </div>
    <!-- Menu Content Section Ends  -->




<?php include('partials/footer.php'); ?>