<?php include('partials/menu.php'); ?>

<div class="main-content">
    <div class="wrapper">
    <h1>Manage Order</h1>
    </div>
</div>

<?php include('partials/footer.php'); ?>